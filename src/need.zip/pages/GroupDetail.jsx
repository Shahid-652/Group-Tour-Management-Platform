import React, { useEffect, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";

const TABS = ["Overview", "Trips", "Expenses", "Tasks", "Members"];

export default function GroupDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [group, setGroup] = useState(null);
  const [tab, setTab] = useState("Overview");
  const [loading, setLoading] = useState(true);

  const loadGroup = useCallback(() => {
    api.get(`/groups/${id}`).then((res) => setGroup(res.data.group));
  }, [id]);

  useEffect(() => {
    setLoading(true);
    api
      .get(`/groups/${id}`)
      .then((res) => setGroup(res.data.group))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="max-w-6xl mx-auto px-6 py-10 text-sand/50">Loading…</div>;
  if (!group) return <div className="max-w-6xl mx-auto px-6 py-10 text-sand/50">Group not found.</div>;

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">
      <div className="flex items-start justify-between mb-6 flex-wrap gap-4">
        <div>
          <p className="label-eyebrow mb-2">Group</p>
          <h1 className="font-display text-4xl mb-2">{group.name}</h1>
          <p className="text-sand/50">{group.description || "No description yet."}</p>
        </div>
        <div className="card px-4 py-3 text-center">
          <p className="text-xs text-sand/40 uppercase tracking-widest">Invite code</p>
          <p className="font-mono text-lagoon text-lg">{group.inviteCode}</p>
        </div>
      </div>

      <div className="flex gap-1 border-b border-white/10 mb-8 overflow-x-auto">
        {TABS.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
              tab === t ? "border-coral text-sand" : "border-transparent text-sand/50 hover:text-sand"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === "Overview" && <OverviewTab group={group} />}
      {tab === "Trips" && <TripsTab groupId={id} />}
      {tab === "Expenses" && <ExpensesTab groupId={id} members={group.members} currentUser={user} />}
      {tab === "Tasks" && <TasksTab groupId={id} members={group.members} />}
      {tab === "Members" && <MembersTab group={group} currentUser={user} onChange={loadGroup} />}
    </div>
  );
}

function OverviewTab({ group }) {
  return (
    <div className="grid md:grid-cols-3 gap-4">
      <div className="card p-6">
        <p className="font-display text-3xl text-coral">{group.members.length}</p>
        <p className="text-sand/50 text-sm mt-1">Members</p>
      </div>
      <div className="card p-6">
        <p className="font-display text-3xl text-lagoon">{group.owner?.name}</p>
        <p className="text-sand/50 text-sm mt-1">Group owner</p>
      </div>
      <div className="card p-6">
        <p className="font-display text-3xl text-gold">{new Date(group.createdAt).toLocaleDateString()}</p>
        <p className="text-sand/50 text-sm mt-1">Created on</p>
      </div>
    </div>
  );
}

// ---------------- TRIPS ----------------
function TripsTab({ groupId }) {
  const [trips, setTrips] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", destination: "", startDate: "", endDate: "" });
  const [error, setError] = useState("");
  const [activeTrip, setActiveTrip] = useState(null);

  const load = () => {
    setLoading(true);
    api.get(`/trips/group/${groupId}`).then((res) => setTrips(res.data.trips)).finally(() => setLoading(false));
  };

  useEffect(load, [groupId]);

  const handleCreate = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await api.post("/trips", { group: groupId, ...form });
      setShowForm(false);
      setForm({ title: "", destination: "", startDate: "", endDate: "" });
      load();
    } catch (err) {
      setError(err.response?.data?.message || "Could not create trip");
    }
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-5">
        <h2 className="font-display text-2xl">Trip schedule</h2>
        <button className="btn-primary" onClick={() => setShowForm(!showForm)}>
          {showForm ? "Cancel" : "+ Plan a trip"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="card p-5 mb-6 grid md:grid-cols-2 gap-4">
          {error && <p className="text-coral text-sm md:col-span-2">{error}</p>}
          <div>
            <label className="label-eyebrow block mb-1.5">Trip title</label>
            <input required className="input-field" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Winter getaway" />
          </div>
          <div>
            <label className="label-eyebrow block mb-1.5">Destination</label>
            <input required className="input-field" value={form.destination} onChange={(e) => setForm({ ...form, destination: e.target.value })} placeholder="Sajek Valley" />
          </div>
          <div>
            <label className="label-eyebrow block mb-1.5">Start date</label>
            <input required type="date" className="input-field" value={form.startDate} onChange={(e) => setForm({ ...form, startDate: e.target.value })} />
          </div>
          <div>
            <label className="label-eyebrow block mb-1.5">End date</label>
            <input required type="date" className="input-field" value={form.endDate} onChange={(e) => setForm({ ...form, endDate: e.target.value })} />
          </div>
          <button type="submit" className="btn-primary md:col-span-2">Save trip</button>
        </form>
      )}

      {loading ? (
        <p className="text-sand/50">Loading trips…</p>
      ) : trips.length === 0 ? (
        <div className="card p-10 text-center text-sand/60">No trips scheduled yet.</div>
      ) : (
        <div className="space-y-3">
          {trips.map((t) => (
            <div key={t._id} className="card p-5">
              <button className="w-full text-left flex items-center justify-between" onClick={() => setActiveTrip(activeTrip === t._id ? null : t._id)}>
                <div>
                  <h3 className="font-display text-lg">{t.title}</h3>
                  <p className="text-sand/50 text-sm">
                    {t.destination} · {new Date(t.startDate).toLocaleDateString()} – {new Date(t.endDate).toLocaleDateString()}
                  </p>
                </div>
                <span className="text-lagoon font-mono text-sm">{activeTrip === t._id ? "−" : "+"}</span>
              </button>
              {activeTrip === t._id && <ItineraryPanel trip={t} onChange={load} />}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ItineraryPanel({ trip, onChange }) {
  const [form, setForm] = useState({ title: "", date: "", time: "", location: "", notes: "" });
  const [error, setError] = useState("");

  const addItem = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await api.post(`/trips/${trip._id}/itinerary`, form);
      setForm({ title: "", date: "", time: "", location: "", notes: "" });
      onChange();
    } catch (err) {
      setError(err.response?.data?.message || "Could not add itinerary item");
    }
  };

  const removeItem = async (itemId) => {
    await api.delete(`/trips/${trip._id}/itinerary/${itemId}`);
    onChange();
  };

  return (
    <div className="mt-5 pt-5 border-t border-white/10">
      <p className="label-eyebrow mb-3">Itinerary</p>
      {trip.itinerary.length === 0 ? (
        <p className="text-sand/40 text-sm mb-4">No itinerary items yet.</p>
      ) : (
        <ul className="space-y-2 mb-5">
          {trip.itinerary.map((item) => (
            <li key={item._id} className="flex items-center justify-between bg-night rounded-lg px-4 py-2.5 text-sm">
              <div>
                <span className="text-lagoon font-mono mr-2">{new Date(item.date).toLocaleDateString()}</span>
                <span className="font-medium">{item.title}</span>
                {item.location && <span className="text-sand/40"> · {item.location}</span>}
              </div>
              <button onClick={() => removeItem(item._id)} className="text-sand/40 hover:text-coral">✕</button>
            </li>
          ))}
        </ul>
      )}
      <form onSubmit={addItem} className="grid md:grid-cols-5 gap-2">
        {error && <p className="text-coral text-xs md:col-span-5">{error}</p>}
        <input required className="input-field text-sm" placeholder="Activity" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
        <input required type="date" className="input-field text-sm" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
        <input className="input-field text-sm" placeholder="Time" value={form.time} onChange={(e) => setForm({ ...form, time: e.target.value })} />
        <input className="input-field text-sm" placeholder="Location" value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} />
        <button type="submit" className="btn-secondary text-sm">Add</button>
      </form>
    </div>
  );
}

// ---------------- EXPENSES ----------------
function ExpensesTab({ groupId, members, currentUser }) {
  const [expenses, setExpenses] = useState([]);
  const [balances, setBalances] = useState({});
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", amount: "", category: "food", paidBy: currentUser?._id || "", splitType: "equal" });
  const [error, setError] = useState("");

  const load = () => {
    setLoading(true);
    Promise.all([
      api.get(`/expenses/group/${groupId}`),
      api.get(`/expenses/group/${groupId}/balances`),
    ])
      .then(([expRes, balRes]) => {
        setExpenses(expRes.data.expenses);
        setBalances(balRes.data.balances);
      })
      .finally(() => setLoading(false));
  };

  useEffect(load, [groupId]);

  const handleCreate = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await api.post("/expenses", { group: groupId, ...form, amount: Number(form.amount) });
      setShowForm(false);
      setForm({ title: "", amount: "", category: "food", paidBy: currentUser?._id || "", splitType: "equal" });
      load();
    } catch (err) {
      setError(err.response?.data?.message || "Could not add expense");
    }
  };

  const memberName = (userId) => members.find((m) => m.user._id === userId)?.user.name || "Unknown";

  return (
    <div>
      <div className="flex justify-between items-center mb-5">
        <h2 className="font-display text-2xl">Expenses</h2>
        <button className="btn-primary" onClick={() => setShowForm(!showForm)}>
          {showForm ? "Cancel" : "+ Add expense"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="card p-5 mb-6 grid md:grid-cols-2 gap-4">
          {error && <p className="text-coral text-sm md:col-span-2">{error}</p>}
          <div>
            <label className="label-eyebrow block mb-1.5">What was it for?</label>
            <input required className="input-field" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Hotel booking" />
          </div>
          <div>
            <label className="label-eyebrow block mb-1.5">Amount (৳)</label>
            <input required type="number" min="0" step="0.01" className="input-field" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} placeholder="5000" />
          </div>
          <div>
            <label className="label-eyebrow block mb-1.5">Category</label>
            <select className="input-field" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              <option value="food">Food</option>
              <option value="transport">Transport</option>
              <option value="accommodation">Accommodation</option>
              <option value="activities">Activities</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div>
            <label className="label-eyebrow block mb-1.5">Paid by</label>
            <select className="input-field" value={form.paidBy} onChange={(e) => setForm({ ...form, paidBy: e.target.value })}>
              {members.map((m) => (
                <option key={m.user._id} value={m.user._id}>{m.user.name}</option>
              ))}
            </select>
          </div>
          <p className="text-sand/40 text-xs md:col-span-2">
            This expense will be split equally among all {members.length} group members automatically.
          </p>
          <button type="submit" className="btn-primary md:col-span-2">Save expense</button>
        </form>
      )}

      <div className="card p-5 mb-6">
        <p className="label-eyebrow mb-4">Balances</p>
        <div className="grid sm:grid-cols-2 gap-3">
          {Object.entries(balances).map(([userId, amount]) => (
            <div key={userId} className="flex items-center justify-between bg-night rounded-lg px-4 py-2.5">
              <span className="text-sm">{memberName(userId)}</span>
              <span className={`font-mono text-sm ${amount > 0 ? "text-lagoon" : amount < 0 ? "text-coral" : "text-sand/40"}`}>
                {amount > 0 ? `+৳${amount}` : amount < 0 ? `-৳${Math.abs(amount)}` : "৳0"}
              </span>
            </div>
          ))}
        </div>
        <p className="text-sand/30 text-xs mt-3">Positive = should receive · Negative = owes the group</p>
      </div>

      {loading ? (
        <p className="text-sand/50">Loading expenses…</p>
      ) : expenses.length === 0 ? (
        <div className="card p-10 text-center text-sand/60">No expenses recorded yet.</div>
      ) : (
        <div className="space-y-2">
          {expenses.map((exp) => (
            <div key={exp._id} className="card p-4 flex items-center justify-between">
              <div>
                <p className="font-medium">{exp.title}</p>
                <p className="text-sand/40 text-xs">
                  Paid by {exp.paidBy.name} · {exp.category} · {new Date(exp.date).toLocaleDateString()}
                </p>
              </div>
              <p className="font-mono text-gold">৳{exp.amount}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ---------------- TASKS ----------------
function TasksTab({ groupId, members }) {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ title: "", description: "", assignedTo: "", dueDate: "" });
  const [error, setError] = useState("");

  const load = () => {
    setLoading(true);
    api.get(`/tasks/group/${groupId}`).then((res) => setTasks(res.data.tasks)).finally(() => setLoading(false));
  };

  useEffect(load, [groupId]);

  const handleCreate = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await api.post("/tasks", { group: groupId, ...form, assignedTo: form.assignedTo || undefined });
      setShowForm(false);
      setForm({ title: "", description: "", assignedTo: "", dueDate: "" });
      load();
    } catch (err) {
      setError(err.response?.data?.message || "Could not create task");
    }
  };

  const updateStatus = async (taskId, status) => {
    await api.put(`/tasks/${taskId}`, { status });
    load();
  };

  const statusStyles = {
    pending: "bg-white/10 text-sand/60",
    in_progress: "bg-gold/20 text-gold",
    done: "bg-lagoon/20 text-lagoon",
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-5">
        <h2 className="font-display text-2xl">Tasks</h2>
        <button className="btn-primary" onClick={() => setShowForm(!showForm)}>
          {showForm ? "Cancel" : "+ Assign task"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleCreate} className="card p-5 mb-6 grid md:grid-cols-2 gap-4">
          {error && <p className="text-coral text-sm md:col-span-2">{error}</p>}
          <div>
            <label className="label-eyebrow block mb-1.5">Task</label>
            <input required className="input-field" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="Book the van" />
          </div>
          <div>
            <label className="label-eyebrow block mb-1.5">Assign to</label>
            <select className="input-field" value={form.assignedTo} onChange={(e) => setForm({ ...form, assignedTo: e.target.value })}>
              <option value="">Unassigned</option>
              {members.map((m) => (
                <option key={m.user._id} value={m.user._id}>{m.user.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label-eyebrow block mb-1.5">Due date</label>
            <input type="date" className="input-field" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} />
          </div>
          <div>
            <label className="label-eyebrow block mb-1.5">Notes</label>
            <input className="input-field" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Optional detail" />
          </div>
          <button type="submit" className="btn-primary md:col-span-2">Save task</button>
        </form>
      )}

      {loading ? (
        <p className="text-sand/50">Loading tasks…</p>
      ) : tasks.length === 0 ? (
        <div className="card p-10 text-center text-sand/60">No tasks assigned yet.</div>
      ) : (
        <div className="space-y-2">
          {tasks.map((t) => (
            <div key={t._id} className="card p-4 flex items-center justify-between flex-wrap gap-3">
              <div>
                <p className="font-medium">{t.title}</p>
                <p className="text-sand/40 text-xs">
                  {t.assignedTo ? `Assigned to ${t.assignedTo.name}` : "Unassigned"}
                  {t.dueDate ? ` · Due ${new Date(t.dueDate).toLocaleDateString()}` : ""}
                </p>
              </div>
              <select
                value={t.status}
                onChange={(e) => updateStatus(t._id, e.target.value)}
                className={`text-xs rounded-full px-3 py-1.5 font-medium border-0 ${statusStyles[t.status]}`}
              >
                <option value="pending">Pending</option>
                <option value="in_progress">In progress</option>
                <option value="done">Done</option>
              </select>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ---------------- MEMBERS ----------------
function MembersTab({ group, currentUser, onChange }) {
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const isOwner = group.owner?._id === currentUser?._id;

  const invite = async (e) => {
    e.preventDefault();
    setError("");
    setInfo("");
    try {
      await api.post(`/groups/${group._id}/invite-friend`, { email });
      setEmail("");
      setInfo("Friend added to the group.");
      onChange();
    } catch (err) {
      setError(err.response?.data?.message || "Could not invite this friend");
    }
  };

  const remove = async (userId) => {
    await api.delete(`/groups/${group._id}/members/${userId}`);
    onChange();
  };

  return (
    <div>
      <form onSubmit={invite} className="card p-5 mb-6 flex flex-wrap gap-3 items-end">
        <div className="flex-1 min-w-[220px]">
          <label className="label-eyebrow block mb-1.5">Invite a friend by email</label>
          <input className="input-field" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="friend@example.com" />
        </div>
        <button type="submit" className="btn-primary">Invite</button>
      </form>

      {error && <p className="text-coral text-sm mb-4">{error}</p>}
      {info && <p className="text-lagoon text-sm mb-4">{info}</p>}

      <div className="space-y-2">
        {group.members.map((m) => (
          <div key={m.user._id} className="card p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span
                className="w-9 h-9 rounded-full flex items-center justify-center text-xs font-semibold text-night"
                style={{ backgroundColor: m.user.avatarColor || "#FF6B4A" }}
              >
                {m.user.name?.[0]?.toUpperCase()}
              </span>

              <div>
                <p className="font-medium text-sm">{m.user.name}</p>
                <p className="text-sand/40 text-xs">{m.user.email}</p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs uppercase tracking-wider text-sand/40 font-mono">{m.role}</span>

              {(isOwner || m.user._id === currentUser?._id) && m.role !== "owner" && (
                <button onClick={() => remove(m.user._id)} className="text-sand/40 hover:text-coral text-sm">
                  {m.user._id === currentUser?._id ? "Leave" : "Remove"}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}