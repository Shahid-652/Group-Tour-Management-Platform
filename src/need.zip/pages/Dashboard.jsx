import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../context/AuthContext";

export default function Dashboard() {
  const { user } = useAuth();
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get("/groups")
      .then((res) => setGroups(res.data.groups))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="max-w-6xl mx-auto px-6 py-10">

      {/* =====================================================
          HEADER
          Functionality unchanged
      ===================================================== */}

      <div className="mb-10">
        <p className="label-eyebrow mb-3">
          Dashboard
        </p>

        <h1 className="font-display text-4xl md:text-5xl text-[#17324D] leading-tight">
          Hey {user?.name?.split(" ")[0]}, where's the crew headed?
        </h1>
      </div>


      {/* =====================================================
          STAT CARDS
          Same values + same calculations
      ===================================================== */}

      <div className="grid md:grid-cols-3 gap-5 mb-14">

        <StatCard
          label="Active groups"
          value={groups.length}
          accent="coral"
          icon="groups"
          decoration="mountain"
        />

        <StatCard
          label="Groups you own"
          value={
            groups.filter(
              (g) => g.owner?._id === user?._id
            ).length
          }
          accent="lagoon"
          icon="person"
          decoration="map"
        />

        <StatCard
          label="Total members reached"
          value={groups.reduce(
            (s, g) => s + g.members.length,
            0
          )}
          accent="gold"
          icon="star"
          decoration="people"
        />

      </div>


      {/* =====================================================
          YOUR GROUPS HEADER
      ===================================================== */}

      <div className="flex items-center justify-between mb-5">

        <h2 className="font-display text-3xl text-[#17324D]">
          Your groups
        </h2>

        <Link
          to="/groups"
          className="
            text-[#3D9B91]
            hover:text-[#526A3F]
            font-semibold
            text-sm
            md:text-base
            transition-colors
            flex
            items-center
            gap-2
          "
        >
          Manage groups
          <span className="text-xl">→</span>
        </Link>

      </div>


      {/* =====================================================
          LOADING
          Functionality unchanged
      ===================================================== */}

      {loading ? (

        <p className="text-[#6F756F]">
          Loading your groups…
        </p>

      ) : groups.length === 0 ? (

        /* ===================================================
           EMPTY GROUP HERO
           Same /groups destination + same create action
        =================================================== */

        <div
          className="
            relative
            overflow-hidden
            rounded-2xl
            border
            border-[#DCCB98]
            min-h-[280px]
            shadow-[0_8px_25px_rgba(38,55,70,0.08)]
          "
        >

          {/* Background */}
          <div
            className="
              absolute
              inset-0
              bg-[#F5E7B9]
            "
          />

          {/* Warm gradient */}
          <div
            className="
              absolute
              inset-0
              bg-gradient-to-r
              from-[#FFF4CC]
              via-[#F8E8B8]/95
              to-[#E9D59E]/60
            "
          />

          {/* Travel image */}
          <div
            className="
              absolute
              right-0
              top-0
              bottom-0
              w-[52%]
              bg-cover
              bg-center
              hidden md:block
            "
            style={{
              backgroundImage:
                "linear-gradient(90deg, rgba(255,244,204,0.95) 0%, rgba(255,244,204,0.25) 45%, rgba(255,244,204,0.05) 100%), url('https://images.unsplash.com/photo-1469474968028-56623f02e42e?auto=format&fit=crop&w=1200&q=85')",
            }}
          />

          {/* Decorative route */}
          <div
            className="
              absolute
              right-[42%]
              bottom-8
              hidden md:block
              text-[#D6A63D]/60
              text-5xl
            "
          >
            ⋯
          </div>

          {/* Content */}
          <div
            className="
              relative
              z-10
              min-h-[280px]
              flex
              items-center
              px-8
              md:px-12
              py-10
            "
          >

            <div className="max-w-xl">

              {/* Icon */}
              <div
                className="
                  w-16
                  h-16
                  rounded-full
                  bg-[#526A3F]
                  flex
                  items-center
                  justify-center
                  mb-6
                  shadow-md
                "
              >
                <svg
                  viewBox="0 0 64 64"
                  className="w-9 h-9 text-[#FFF4CC]"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="3"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="M8 48L25 27L34 37L43 22L56 48" />
                  <path d="M17 48L27 36L35 44" />
                </svg>
              </div>


              {/* Eyebrow */}
              <p
                className="
                  text-[#3D9B91]
                  uppercase
                  tracking-[0.22em]
                  text-sm
                  font-semibold
                  mb-3
                "
              >
                Build your travel squad
              </p>


              {/* Main message */}
              <p
                className="
                  font-display
                  text-2xl
                  md:text-3xl
                  text-[#17324D]
                  leading-tight
                  mb-7
                "
              >
                You haven't joined or created any group yet.
              </p>


              {/* Existing action */}
              <Link
                to="/groups"
                className="
                  inline-flex
                  items-center
                  gap-3
                  bg-[#E9683D]
                  hover:bg-[#D95732]
                  text-white
                  font-semibold
                  rounded-xl
                  px-6
                  py-3
                  shadow-md
                  hover:shadow-lg
                  transition-all
                "
              >
                <span className="text-2xl leading-none">
                  +
                </span>

                <span>
                  Create your first group
                </span>
              </Link>

            </div>

          </div>

        </div>

      ) : (

        /* ===================================================
           EXISTING GROUPS
           Same mapping + same route
        =================================================== */

        <div className="grid md:grid-cols-3 gap-5">

          {groups.map((g) => (

            <Link
              to={`/groups/${g._id}`}
              key={g._id}
              className="
                card
                p-6
                hover:-translate-y-1
                transition-all
                block
              "
            >

              <div
                className="
                  w-12
                  h-12
                  rounded-xl
                  mb-5
                  flex
                  items-center
                  justify-center
                  font-display
                  font-semibold
                  text-white
                  shadow-sm
                "
                style={{
                  backgroundColor:
                    g.coverColor || "#3D9B91",
                }}
              >
                {g.name?.[0]?.toUpperCase()}
              </div>


              <h3 className="font-display text-xl text-[#17324D] mb-2">
                {g.name}
              </h3>


              <p className="text-[#6F756F] text-sm mb-4 line-clamp-2">
                {g.description || "No description yet."}
              </p>


              <div
                className="
                  flex
                  items-center
                  justify-between
                  text-xs
                  text-[#6F756F]
                  font-mono
                  border-t
                  border-[#D8D0BE]
                  pt-4
                "
              >
                <span>
                  {g.members.length} members
                </span>

                <span>
                  Code: {g.inviteCode}
                </span>
              </div>

            </Link>

          ))}

        </div>

      )}

    </div>
  );
}


/* =========================================================
   STAT CARD

   Only visual structure changed.
   Values / props / calculations remain untouched.
========================================================= */

function StatCard({
  label,
  value,
  accent,
  icon,
  decoration,
}) {

  const accentMap = {
    coral: {
      circle: "#E9683D",
      text: "#E9683D",
    },

    lagoon: {
      circle: "#3D9B91",
      text: "#3D9B91",
    },

    gold: {
      circle: "#D6A63D",
      text: "#D6A63D",
    },
  };


  const colors =
    accentMap[accent] || accentMap.coral;


  return (
    <div
      className="
        relative
        overflow-hidden
        rounded-2xl
        border
        border-[#DCCB98]
        bg-gradient-to-br
        from-[#FFF4CC]
        to-[#F0DFAE]
        min-h-[158px]
        p-7
        shadow-[0_7px_20px_rgba(38,55,70,0.08)]
      "
    >

      {/* Decorative background */}

      <div
        className="
          absolute
          right-4
          bottom-1
          opacity-20
          pointer-events-none
        "
        style={{
          color: colors.circle,
        }}
      >

        {decoration === "mountain" && (
          <svg
            viewBox="0 0 180 100"
            className="w-44 h-24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <path d="M5 90L55 40L85 68L115 25L175 90" />
            <path d="M70 90L100 60L135 90" />
            <path d="M120 20C135 20 145 30 145 43" />
            <path d="M145 43L145 55" />
            <circle cx="145" cy="16" r="5" />
          </svg>
        )}


        {decoration === "map" && (
          <svg
            viewBox="0 0 180 100"
            className="w-44 h-24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
          >
            <path d="M15 25L60 10L110 25L160 8V78L110 94L60 78L15 94V25Z" />
            <path d="M60 10V78" />
            <path d="M110 25V94" />
            <path d="M130 20C130 12 136 7 143 7C150 7 156 12 156 20C156 29 143 42 143 42C143 42 130 29 130 20Z" />
          </svg>
        )}


        {decoration === "people" && (
          <svg
            viewBox="0 0 180 100"
            className="w-44 h-24"
            fill="currentColor"
          >
            <circle cx="90" cy="35" r="12" />
            <circle cx="55" cy="43" r="9" />
            <circle cx="125" cy="43" r="9" />
            <path d="M63 82C63 62 75 51 90 51C105 51 117 62 117 82Z" />
            <path d="M25 82C25 67 36 57 50 57C57 57 63 60 68 65C62 70 58 76 57 82Z" />
            <path d="M155 82C155 67 144 57 130 57C123 57 117 60 112 65C118 70 122 76 123 82Z" />
          </svg>
        )}

      </div>


      {/* Icon */}

      <div
        className="
          relative
          z-10
          w-14
          h-14
          rounded-full
          flex
          items-center
          justify-center
          text-white
          shadow-sm
          mb-3
        "
        style={{
          backgroundColor: colors.circle,
        }}
      >

        {icon === "groups" && (
          <svg
            viewBox="0 0 24 24"
            className="w-7 h-7"
            fill="currentColor"
          >
            <circle cx="9" cy="8" r="3" />
            <circle cx="16" cy="9" r="2.5" />
            <path d="M3 19C3 14.8 5.5 12 9 12C12.5 12 15 14.8 15 19Z" />
            <path d="M14 13C15 12.3 16 12 17 12C19.8 12 21 14.2 21 17V19H16" />
          </svg>
        )}


        {icon === "person" && (
          <svg
            viewBox="0 0 24 24"
            className="w-7 h-7"
            fill="currentColor"
          >
            <circle cx="12" cy="7" r="4" />
            <path d="M4 21C4 16.5 7.2 13 12 13C16.8 13 20 16.5 20 21Z" />
          </svg>
        )}


        {icon === "star" && (
          <svg
            viewBox="0 0 24 24"
            className="w-7 h-7"
            fill="currentColor"
          >
            <path d="M12 2.5L14.9 8.4L21.4 9.3L16.7 13.9L17.8 20.4L12 17.3L6.2 20.4L7.3 13.9L2.6 9.3L9.1 8.4Z" />
          </svg>
        )}

      </div>


      {/* Number */}

      <p
        className="
          absolute
          left-28
          top-8
          font-display
          text-4xl
          md:text-5xl
          text-[#17324D]
          z-10
        "
      >
        {value}
      </p>


      {/* Label */}

      <p
        className="
          absolute
          left-28
          top-[88px]
          text-[#52606D]
          text-base
          font-medium
          z-10
        "
      >
        {label}
      </p>

    </div>
  );
}